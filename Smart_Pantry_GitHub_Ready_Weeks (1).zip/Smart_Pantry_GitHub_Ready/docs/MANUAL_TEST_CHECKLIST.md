# Smart Pantry final manual test checklist

Run:

```bash
python3 Smart_Pantry_Final.py
```

Then complete these checks on the final submission computer.

- [ ] Main Smart Pantry window opens without a terminal error.
- [ ] Add an item priced **per item** and confirm it appears in View Inventory.
- [ ] Add an item priced **per kilogram** using a decimal weight such as `1.25` and confirm the display says `kg` and `/ kg`.
- [ ] Add two items with the same name but different expiry dates and confirm both batches remain visible.
- [ ] Update the quantity/weight of one batch and confirm the correct batch changes.
- [ ] Delete one batch and confirm the other same-name batch remains.
- [ ] Mark a food as a regular item with a minimum stock amount, lower its quantity below the minimum, and confirm a shopping recommendation appears.
- [ ] Add something manually to the shopping list and confirm the estimated shopping total updates.
- [ ] Add/update a household member's lunch and dinner response.
- [ ] Confirm the meal-board status remains after clearing its message.
- [ ] Open Messages and clear one message, then a category.
- [ ] Set a weekly budget and confirm remaining/projected spending is shown.
- [ ] Close Smart Pantry normally.
- [ ] Reopen Smart Pantry and confirm the inventory, shopping list, meal board and budget are still present.
- [ ] Confirm `smart_pantry_data.json` was created beside `Smart_Pantry_Final.py`.

If all boxes pass, use this exact version for your recorded demonstration and GitHub submission.
